    // ── Super Admin ID (solo para resaltar visualmente su fila en el Panel
    // Admin; la autorización real ya se valida en el servidor con la sesión) ──
    const SUPER_ADMIN_ID = "1192236737565577287";

    // ── Estado global de sesión ───────────────────────────────────────────────
    // Todas las variables de sesión viven aquí. Para resetear la sesión completa
    // usa resetEstado() — no las borres una por una en distintos archivos.
    let currentUser     = null;  // objeto Discord del usuario logueado
    let currentDNI      = null;  // datos del carnet (dni, nombre, etc.)
    let currentCuenta   = null;  // datos de la cuenta bancaria
    let adminTargetUser = null;  // usuario objetivo en panel admin banco
    let countdownInterval = null; // intervalo del countdown de sueldo

    function resetEstado() {
      currentUser = null;
      currentDNI  = null;
      currentCuenta = null;
      adminTargetUser = null;
      if (countdownInterval) { clearInterval(countdownInterval); countdownInterval = null; }
    }

    // ── Pantallas ─────────────────────────────────────────────────────────────
    const screens = ['landing','dashboard','registro-civil','banco-screen','admin-screen','tienda-screen','mercado-screen','concesionario-screen','mis-autos-screen','inventario-screen','admin-tienda-screen','perfil-publico-screen','panel-admin-screen','staff-panel-screen','comisaria-screen','casino-screen','apuestas-screen','admin-casino-screen','empresas-screen','admin-empresas-screen','logros-screen','error-403','error-404'];

    // ── Indicador de sección activa ──────────────────────────────────────────
    let _sectionIndicatorTimer = null;
    function mostrarIndicadorSeccion(id) {
      const labels = {
        'landing': null,
        'dashboard': null,
        'registro-civil': 'Registro Civil',
        'banco-screen': 'Banco',
        'admin-screen': 'Admin Banco',
        'tienda-screen': 'Tienda',
        'concesionario-screen': 'Concesionario',
        'mis-autos-screen': 'Tus Autos',
        'inventario-screen': 'Inventario',
        'admin-tienda-screen': 'Admin Tienda',
        'perfil-publico-screen': 'Perfil Público',
        'panel-admin-screen': 'Panel Admin',
        'staff-panel-screen': 'Panel Staff',
        'comisaria-screen': 'Comisaría Virtual',
        'casino-screen': 'Casino',
        'apuestas-screen': 'Apuestas',
        'admin-casino-screen': 'Admin Casino',
        'empresas-screen': 'Empresas',
        'admin-empresas-screen': 'Administrar Empresas',
        'logros-screen': 'Logros',
      };
      const label = labels[id];
      let indicator = document.getElementById('section-indicator');
      if (!indicator) {
        indicator = document.createElement('div');
        indicator.id = 'section-indicator';
        document.body.appendChild(indicator);
      }
      if (!label) { indicator.classList.remove('si-visible'); return; }
      indicator.textContent = label;
      indicator.classList.add('si-visible');
      clearTimeout(_sectionIndicatorTimer);
      _sectionIndicatorTimer = setTimeout(() => indicator.classList.remove('si-visible'), 1800);
    }

    // ── Compatibilidad multi-página ──────────────────────────────────────────
    // El sitio se separó en un .html por apartado (ver CC_PAGE_MAP definido
    // inline en cada página, antes de este script). Si mostrarPantalla() pide
    // un id que no vive en el HTML de la página actual, en vez de fallar en
    // silencio navegamos de verdad a la página que sí lo contiene. Si el id
    // corresponde a esta misma página (o no hay mapa), se comporta como
    // siempre (toggle de clases .active).
    function mostrarPantalla(id, opts = {}) {
      if (!document.getElementById(id) && window.CC_PAGE_MAP && window.CC_PAGE_MAP[id]) {
        // Caso especial: la restauración automática de sesión (initSesion)
        // llama a goToDashboard(user, true) -> mostrarPantalla('dashboard', { autoRestore: true })
        // en TODAS las páginas para reponer el usuario logueado. Si ya estamos
        // en un apartado propio (no landing), eso no debe rebotarnos al
        // dashboard. OJO: este chequeo solo debe aplicar a esa restauración
        // automática (opts.autoRestore) — NO a los botones "Volver" de cada
        // sección (que también llaman a mostrarPantalla('dashboard') pero sin
        // ese flag), porque si no, "Volver" queda muerto en todas las páginas.
        if (opts.autoRestore && id === 'dashboard' && window.CC_CURRENT_SCREEN && window.CC_CURRENT_SCREEN !== 'landing') {
          return;
        }
        window.location.href = window.CC_PAGE_MAP[id];
        return;
      }
      const prev = screens.find(s => {
        const el = document.getElementById(s);
        return el && el.classList.contains('active');
      });
      const isDashToSection = prev === 'dashboard' && id !== 'dashboard' && id !== 'landing';
      const isSectionToDash = id === 'dashboard' && prev !== 'landing';

      screens.forEach(s => {
        const el = document.getElementById(s);
        if (!el) return;
        if (s === id) {
          el.classList.add('active');
          if (isDashToSection) {
            el.classList.add('screen-enter');
            requestAnimationFrame(() => {
              requestAnimationFrame(() => el.classList.remove('screen-enter'));
            });
          } else if (isSectionToDash) {
            el.classList.add('screen-return');
            requestAnimationFrame(() => {
              requestAnimationFrame(() => el.classList.remove('screen-return'));
            });
          }
        } else {
          el.classList.remove('active');
        }
      });
      mostrarIndicadorSeccion(id);
      document.body.classList.toggle('oculta-logo-corner', id !== 'landing' && id !== 'dashboard');
    }

    function volverDashboard() { mostrarPantalla('dashboard'); _navegandoProgramaticamente = true; window.history.pushState({ screen: 'dashboard' }, '', '/'); setTimeout(() => { _navegandoProgramaticamente = false; }, 50); }

    // ── Compatibilidad multi-página: auto-carga de cada sección ─────────────
    // Antes (SPA de una sola página) los nav-cards del dashboard hacían
    // onclick="abrirSeccion('banco-screen')" — al cambiar de
    // "pantalla" sin recargar, ese cargarBanco() sí corría en la sección ya
    // visible. Ahora cada apartado es su propio archivo .html: abrirSeccion
    // navega de verdad a banco.html, así que ese cargarBanco() encadenado se
    // ejecuta (y falla, porque #banco-loading no existe) en la página VIEJA
    // que se está por abandonar — nunca llega a pintar nada en banco.html.
    // Resultado: la sección de destino se queda mostrando el esqueleto de
    // carga para siempre (todo "no carga").
    // Este mapa reemplaza esa dependencia: cuando la sesión se confirma en
    // CADA página (ver goToDashboard más abajo), se llama a la función que
    // corresponde a la sección actual (window.CC_CURRENT_SCREEN), sin
    // importar desde dónde se navegó hasta aquí.
    const CC_SECTION_ENTRY = {
      'registro-civil':        () => { if (typeof cargarDNI === 'function') cargarDNI(); },
      'banco-screen':          () => { if (typeof cargarBanco === 'function') cargarBanco(); },
      'mercado-screen':        () => { if (typeof cargarMercado === 'function') cargarMercado(); },
      'tienda-screen':         () => { if (typeof cargarTienda === 'function') cargarTienda(); },
      'concesionario-screen':  () => { if (typeof cargarConcesionario === 'function') cargarConcesionario(); },
      'mis-autos-screen':      () => { if (typeof cargarMisAutos === 'function') cargarMisAutos(); },
      'inventario-screen':     () => { if (typeof cargarInventario === 'function') cargarInventario(); },
      'perfil-publico-screen': () => { if (typeof cargarPerfilPublico === 'function') cargarPerfilPublico(); },
      'empresas-screen':       () => { if (typeof cargarEmpresas === 'function') cargarEmpresas(); },
      'logros-screen':         () => { if (typeof cargarLogros === 'function') cargarLogros(); },
      'casino-screen':         () => { if (typeof cargarCasino === 'function') cargarCasino(); },
      'apuestas-screen':       () => { if (typeof cargarApuestas === 'function') cargarApuestas(); },
      // Estas ya hacen su propia verificación de acceso al servidor; al estar
      // ya en su página (abrirSeccion no navega si el elemento ya existe),
      // llamarlas de nuevo aquí solo dispara esa verificación + su carga.
      'comisaria-screen':      () => { if (typeof abrirComisaria === 'function') abrirComisaria(); },
      'panel-admin-screen':    () => { if (typeof abrirPanelAdmin === 'function') abrirPanelAdmin(); },
      'staff-panel-screen':    () => { if (typeof abrirPanelStaff === 'function') abrirPanelStaff(); },
      'admin-screen':          () => { if (typeof abrirAdminBanco === 'function') abrirAdminBanco(); },
      'admin-tienda-screen':   () => { if (typeof abrirAdminTiendaPanel === 'function') abrirAdminTiendaPanel(); },
      'admin-empresas-screen': () => { if (typeof abrirAdminEmpresasPanel === 'function') abrirAdminEmpresasPanel(); },
      'admin-casino-screen':   () => { if (typeof abrirAdminCasino === 'function') abrirAdminCasino(); },
    };

    async function goToDashboard(user, opts = {}) {
      currentUser = user;
      actualizarBotonLogin();
      // NOTA multi-página: estos elementos solo existen en dashboard.html /
      // index.html. En el resto de páginas goToDashboard() se sigue llamando
      // al restaurar sesión (initSesion), pero no hay dónde pintar nombre o
      // avatar — cada asignación se protege con un chequeo de existencia.
      const elName = document.getElementById('discord-name');
      if (elName) elName.textContent = user.name;
      const elTag = document.getElementById('discord-tag');
      if (elTag) elTag.textContent = user.tag || '';
      const elAvatar = document.getElementById('discord-avatar');
      if (elAvatar) elAvatar.src = user.avatar;

      // Card de perfil (avatar, nombre, badges, bio) y saldo bancario
      const elProfileAvatar = document.getElementById('profile-avatar');
      if (elProfileAvatar) elProfileAvatar.src = user.avatar;
      const elProfileName = document.getElementById('profile-name');
      if (elProfileName) elProfileName.textContent = user.name;
      cargarPerfilDashboard();

      // Nota: los antiguos paneles administrativos separados (Banco, Tienda,
      // Empresas, Panel Admin, Casino) fueron reemplazados por los botones
      // únicos "Staff" y "Admin" del nav-grid. Son tres roles independientes
      // entre sí. La lógica de permisos vive en abrirPanelAdmin() (analiza
      // acceso vía /api/admin?action=verificar), abrirPanelStaff() (analiza
      // acceso vía /api/admin?action=verificarStaff) y abrirComisaria()
      // (analiza acceso vía /api/comisaria?action=verificar, para el nav-card
      // "Comisaría Virtual", separado del apartado "Staff").

      // Si el usuario llegó a "/" a propósito (botón de casa / irAlPortal),
      // no lo rebotamos de vuelta a dashboard.html: se queda en la landing,
      // pero con la sesión ya restaurada (nombre, avatar, botón de login).
      if (!opts.quedarseEnLanding) {
        mostrarPantalla('dashboard', { autoRestore: !!opts.autoRestore });
      }

      // Auto-carga de la sección actual (banco, registro civil, mercado,
      // etc.) — ver comentario de CC_SECTION_ENTRY más arriba.
      const entradaSeccion = CC_SECTION_ENTRY[window.CC_CURRENT_SCREEN];
      if (entradaSeccion) {
        try { entradaSeccion(); } catch (e) { console.error('Error al cargar la sección', window.CC_CURRENT_SCREEN, e); }
      }

      if (typeof notifIniciar === 'function') notifIniciar();
    }

    function goToLanding() {
      resetEstado();
      if (typeof notifDetener === 'function') notifDetener();
      // La sesión ahora vive en una cookie httpOnly del servidor; se cierra
      // pidiéndole al servidor que la borre (antes solo se borraba un dato
      // en localStorage, que ni siquiera era la fuente real de verdad).
      fetch('/api/logout', { method: 'POST' }).catch(() => {});
      actualizarBotonLogin();
      mostrarPantalla('landing');
    }

    // Vuelve a la pantalla de inicio (portal) SIN cerrar sesión. A diferencia
    // de goToLanding(), no borra el estado ni pide al servidor cerrar la
    // cookie: el usuario sigue logueado y puede volver al panel cuando quiera.
    function irAlPortal() {
      const pill = document.getElementById('user-pill');
      if (pill) pill.classList.remove('open');
      actualizarBotonLogin();
      try { sessionStorage.setItem('cc_ir_portal', '1'); } catch {}
      mostrarPantalla('landing');
      _navegandoProgramaticamente = true;
      window.history.pushState({ screen: 'landing' }, '', '/');
      setTimeout(() => { _navegandoProgramaticamente = false; }, 50);
    }

    // Si hay sesión activa, el botón de la landing ya no debe mandar a
    // /auth/login (eso reiniciaría el login con Discord innecesariamente):
    // debe llevar directo al panel. Sin sesión, se comporta como siempre.
    function actualizarBotonLogin() {
      const btn = document.getElementById('login-btn');
      const txt = document.getElementById('login-btn-text');
      if (!btn) return;
      if (currentUser) {
        btn.href = '#';
        txt.textContent = 'Ir al Panel';
        btn.onclick = (e) => {
          e.preventDefault();
          mostrarPantalla('dashboard');
          _navegandoProgramaticamente = true;
          window.history.pushState({ screen: 'dashboard' }, '', '/');
          setTimeout(() => { _navegandoProgramaticamente = false; }, 50);
        };
      } else {
        btn.href = '/auth/login';
        txt.textContent = 'Entrar con Discord';
        btn.onclick = null;
      }
    }

    let _navegandoProgramaticamente = false;

    function abrirSeccion(id) {
      mostrarPantalla(id);
      _navegandoProgramaticamente = true;
      window.history.pushState({ screen: id }, '', '/');
      setTimeout(() => { _navegandoProgramaticamente = false; }, 50);
    }

    // ── PANEL ADMIN: punto de entrada único ──────────────────────────────────
    // Un solo botón "Admin" visible para todos en el dashboard. Al entrar se
    // analiza el acceso contra el servidor (nunca se confía en el cliente):
    // GET /api/admin?action=verificar responde { esAdmin, esSuperAdmin } según
    // la tabla `admins`, que solo el super admin puede editar desde dentro de
    // este mismo panel (agregando/quitando IDs de Discord).
    let paEsAdmin = false;
    let paEsSuperAdmin = false;

    async function abrirPanelAdmin() {
      abrirSeccion('panel-admin-screen');
      document.getElementById('pa-acceso-loading').style.display = 'flex';
      document.getElementById('pa-sin-acceso').style.display = 'none';
      document.getElementById('pa-contenido').style.display = 'none';
      const barra = document.getElementById('pa-barra-progreso');
      barra.style.width = '0%';

      setTimeout(() => { barra.style.width = '60%'; }, 100);
      setTimeout(() => { barra.style.width = '85%'; }, 600);

      try {
        const r = await fetch('/api/admin?action=verificar');
        const data = await r.json();
        paEsAdmin = data.esAdmin || false;
        paEsSuperAdmin = data.esSuperAdmin || false;
      } catch {
        paEsAdmin = false;
        paEsSuperAdmin = false;
      }

      barra.style.width = '100%';
      await new Promise(res => setTimeout(res, 500));
      document.getElementById('pa-acceso-loading').style.display = 'none';

      if (!paEsAdmin) {
        document.getElementById('pa-sin-acceso').style.display = 'flex';
        return;
      }

      document.getElementById('pa-contenido').style.display = 'flex';

      // Gestionar admins (agregar/quitar por Discord ID) es exclusivo del
      // super admin; el resto del hub es para cualquier admin autorizado.
      const btnAdmins = document.getElementById('pa-hub-btn-admins');
      if (btnAdmins) btnAdmins.style.display = paEsSuperAdmin ? '' : 'none';

      // El panel ahora es un hub de botones: cada sección solo carga sus
      // datos cuando el usuario realmente entra a ella (paAbrirSub), en vez
      // de disparar las 4 llamadas de golpe como antes.
      paVolverHub();
    }

    function volverPanelAdmin() {
      abrirPanelAdmin();
    }

    // ── Panel Admin: navegación hub ↔ subsección ─────────────────────────────
    // Sustituye el scroll largo de siempre: el hub muestra una grilla de
    // botones y cada uno abre su propio panel, cargando sus datos recién en
    // ese momento (antes se pedían las 4 secciones de gestión de una sola vez
    // al entrar al Panel Admin, aunque el admin solo quisiera ver una).
    function paAbrirSub(id) {
      const hub = document.getElementById('pa-hub-view');
      if (hub) hub.style.display = 'none';
      document.querySelectorAll('#pa-contenido .pa-sub').forEach(el => el.classList.remove('visible'));
      const sub = document.getElementById('pa-sub-' + id);
      if (!sub) return;
      sub.classList.add('visible');

      if (id === 'admins' && paEsSuperAdmin && typeof paCargarAdmins === 'function') paCargarAdmins();
      if (id === 'policia' && typeof gpCargarPolicias === 'function') gpCargarPolicias();
      if (id === 'staff' && typeof psCargarStaff === 'function') psCargarStaff();
      if (id === 'stafflogs' && typeof slCargarLogs === 'function') slCargarLogs();
    }

    function paVolverHub() {
      document.querySelectorAll('#pa-contenido .pa-sub').forEach(el => el.classList.remove('visible'));
      const hub = document.getElementById('pa-hub-view');
      if (hub) hub.style.display = 'flex';
    }

    // ── PANEL STAFF: punto de entrada único ──────────────────────────────────
    // Rol independiente de "admins". Al entrar se analiza el acceso contra el
    // servidor: GET /api/admin?action=verificarStaff responde { esStaff }
    // según la tabla `staff`, que solo los admins pueden editar desde dentro
    // del Panel Admin (sección "Gestión de Staff"). Quien es staff pero no
    // admin nunca ve el Panel Admin ni sus herramientas.
    async function abrirPanelStaff() {
      abrirSeccion('staff-panel-screen');
      document.getElementById('ps-acceso-loading').style.display = 'flex';
      document.getElementById('ps-sin-acceso').style.display = 'none';
      document.getElementById('ps-contenido').style.display = 'none';
      const barra = document.getElementById('ps-barra-progreso');
      barra.style.width = '0%';

      setTimeout(() => { barra.style.width = '60%'; }, 100);
      setTimeout(() => { barra.style.width = '85%'; }, 600);

      let esStaff = false;
      try {
        const r = await fetch('/api/admin?action=verificarStaff');
        const data = await r.json();
        esStaff = data.esStaff || false;
      } catch {
        esStaff = false;
      }

      barra.style.width = '100%';
      await new Promise(res => setTimeout(res, 500));
      document.getElementById('ps-acceso-loading').style.display = 'none';

      if (!esStaff) {
        document.getElementById('ps-sin-acceso').style.display = 'flex';
        return;
      }

      document.getElementById('ps-contenido').style.display = 'flex';
      if (typeof sgpCargarPolicias === 'function') sgpCargarPolicias();
    }

    // Openers de las herramientas agrupadas dentro del Panel Admin (y ahora
    // también del Panel Staff, para Admin Banco y Admin Empresas). Cada una
    // navega a su pantalla, dispara la carga de datos correspondiente, y
    // recuerda desde dónde se entró para que el botón "Volver" regrese al
    // panel correcto (Admin o Staff).
    let _herramientaOrigen = 'admin';

    function abrirAdminBanco(origen) {
      _herramientaOrigen = origen === 'staff' ? 'staff' : 'admin';
      abrirSeccion('admin-screen');
      if (typeof cargarAdminUsuarios === 'function') cargarAdminUsuarios();
      if (typeof actualizarBadgePrestamos === 'function') actualizarBadgePrestamos();
    }

    function abrirAdminTiendaPanel() {
      _herramientaOrigen = 'admin';
      abrirSeccion('admin-tienda-screen');
      if (typeof cargarAdminProductos === 'function') cargarAdminProductos();
    }

    function abrirAdminEmpresasPanel(origen) {
      _herramientaOrigen = origen === 'staff' ? 'staff' : 'admin';
      abrirSeccion('admin-empresas-screen');
      if (typeof cargarAdminEmpresas === 'function') cargarAdminEmpresas();
    }

    function volverDesdeHerramienta() {
      if (_herramientaOrigen === 'staff') abrirPanelStaff();
      else abrirPanelAdmin();
    }

    // Interceptar botón atrás del navegador/celular
    window.addEventListener('popstate', () => {
      if (_navegandoProgramaticamente) return;
      if (currentUser) {
        mostrarPantalla('dashboard');
        _navegandoProgramaticamente = true;
        window.history.pushState({ screen: 'dashboard' }, '', '/');
        setTimeout(() => { _navegandoProgramaticamente = false; }, 50);
      }
    });

    // ── Login desde URL params o sesión guardada ──────────────────────────────
    // NOTA multi-página: #f-fecha solo existe en registro-civil.html. En el
    // resto de páginas este bloque debe protegerse: si no, el error frenaba
    // la ejecución del resto del archivo (initSesion, listeners, etc. nunca
    // se registraban en ninguna otra página).
    const elFFecha = document.getElementById('f-fecha');
    if (elFFecha) elFFecha.max = new Date().toISOString().split('T')[0];

    // La identidad ya no se lee de la URL ni de localStorage (cualquiera podía
    // editar esos valores y hacerse pasar por otro usuario). Ahora se le
    // pregunta al servidor quién está autenticado según la cookie de sesión
    // firmada que dejó /api/callback al iniciar sesión con Discord.
    (async function initSesion() {
      try {
        const r = await fetch('/api/me');
        if (r.ok) {
          const data = await r.json();
          if (data.autenticado) {
            const user = {
              id: data.id,
              name: data.name,
              tag: data.tag,
              avatar: data.avatar,
              esSuperAdmin: data.esSuperAdmin,
            };
            // Solo reescribe la URL a "/" si venimos de la landing (root);
            // en cualquier otra página (banco.html, tienda.html, etc.) no
            // corresponde tocar la URL actual al restaurar sesión.
            const enLanding = window.location.pathname === '/' || /\/index\.html$/.test(window.location.pathname);
            if (enLanding) {
              window.history.replaceState({ screen: 'dashboard' }, '', '/');
            }
            // Si el usuario llegó a la landing a propósito (botón de casa,
            // ver irAlPortal), no lo mandamos de vuelta a dashboard.html:
            // debe poder ver el portal con la sesión abierta.
            let quedarseEnLanding = false;
            if (enLanding) {
              try {
                if (sessionStorage.getItem('cc_ir_portal') === '1') {
                  sessionStorage.removeItem('cc_ir_portal');
                  quedarseEnLanding = true;
                }
              } catch {}
            }
            goToDashboard(user, { autoRestore: true, quedarseEnLanding });
          }
        }
      } catch {}
    })();

    // ── User pill ─────────────────────────────────────────────────────────────
    // NOTA multi-página: user-pill/logout-btn/portal-btn viven dentro de la
    // sección "dashboard", que ahora solo existe en dashboard.html/index.html.
    // Se protege cada listener para que el resto del script siga corriendo
    // igual en las páginas donde estos botones no existen.
    const elUserPill = document.getElementById('user-pill');
    if (elUserPill) {
      elUserPill.addEventListener('click', (e) => {
        if (e.target.closest('#logout-btn')) return;
        elUserPill.classList.toggle('open');
      });
      document.addEventListener('click', (e) => {
        if (!elUserPill.contains(e.target)) elUserPill.classList.remove('open');
      });
    }
    const elLogoutBtn = document.getElementById('logout-btn');
    if (elLogoutBtn) {
      elLogoutBtn.addEventListener('click', () => {
        if (elUserPill) elUserPill.classList.remove('open');
        goToLanding();
      });
    }
    const elPortalBtn = document.getElementById('portal-btn');
    if (elPortalBtn) {
      elPortalBtn.addEventListener('click', () => {
        irAlPortal();
      });
    }


    // ── Utilidades globales ──────────────────────────────────────────────────
    // Función única de escape HTML (antes: escHtml en tienda/admin-tienda,
    // cvEsc en comisaria — ahora una sola definición global)
    function escHtml(str) {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    // Función única de formato de pesos CLP (antes: formatearSaldo, apFmt, casinoFmt)
    function formatCLP(n) {
      return '$' + Math.round(Number(n) || 0).toLocaleString('es-CL');
    }

    // ── Contador animado (mejora visual v9) ──────────────────────────────────
    // Anima un número desde 0 hasta targetValue, formateando cada frame con
    // formatFn (ej: formatCLP). Uso: ccAnimateNumber(el, 15000, formatCLP)
    // Respeta prefers-reduced-motion (setea el valor final de una vez).
    function ccAnimateNumber(el, targetValue, formatFn, duration = 700) {
      if (!el) return;
      const target = Number(targetValue) || 0;
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        el.textContent = formatFn(target);
        return;
      }
      const startTime = performance.now();
      function tick(now) {
        const progress = Math.min((now - startTime) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = formatFn(Math.round(target * eased));
        if (progress < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    }

    // ── Feedback de victoria/derrota (sonido + microanimación) ───────────────
    // Compartido entre Casino y Apuestas para que la sensación de "ganaste"
    // o "perdiste" sea consistente en toda la app. No reemplaza los sonidos
    // específicos de cada juego (giro de ruleta, motor del avión, etc.),
    // se suma como una capa extra justo cuando se revela el resultado.
    let _fbAudioCtx = null;
    function _fbGetCtx() {
      if (!_fbAudioCtx) {
        try { _fbAudioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch {}
      }
      return _fbAudioCtx;
    }

    function sonidoVictoria() {
      const ctx = _fbGetCtx(); if (!ctx) return;
      // Arpegio ascendente y brillante (do-mi-sol-do agudo)
      const notas = [523.25, 659.25, 783.99, 1046.5];
      notas.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = 'triangle';
        osc.frequency.value = freq;
        const t = ctx.currentTime + i * 0.09;
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.16, t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.32);
        osc.start(t); osc.stop(t + 0.34);
      });
    }

    function sonidoDerrota() {
      const ctx = _fbGetCtx(); if (!ctx) return;
      // Descenso grave y corto, tipo "buzzer" suave (no agresivo)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'sawtooth';
      const t = ctx.currentTime;
      osc.frequency.setValueAtTime(220, t);
      osc.frequency.exponentialRampToValueAtTime(90, t + 0.4);
      gain.gain.setValueAtTime(0.1, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
      osc.start(t); osc.stop(t + 0.45);
    }

    // Dispara un puñado de "confeti" (emojis) cayendo dentro del elemento
    // de resultado. Liviano: sin librerías, solo spans con animación CSS
    // que se autodestruyen.
    function dispararConfeti(el) {
      if (!el) return;
      const wrap = document.createElement('div');
      wrap.className = 'fb-confeti-wrap';
      const piezas = ['🎉', '✨', '💰', '🪙'];
      const cantidad = 10;
      for (let i = 0; i < cantidad; i++) {
        const span = document.createElement('span');
        span.className = 'fb-confeti-pieza';
        span.textContent = piezas[Math.floor(Math.random() * piezas.length)];
        span.style.left = (Math.random() * 90 + 2) + '%';
        span.style.animationDelay = (Math.random() * 0.15) + 's';
        span.style.fontSize = (12 + Math.random() * 10) + 'px';
        wrap.appendChild(span);
      }
      el.appendChild(wrap);
      setTimeout(() => wrap.remove(), 1200);
    }

    // Punto de entrada único: aplica la animación de pulso/sacudida sobre
    // el elemento de resultado (clásicamente .casino-resultado) y reproduce
    // el sonido correspondiente. Se puede llamar en cualquier juego o
    // historial donde se revele un resultado de victoria/derrota.
    function feedbackResultado(el, gano) {
      if (el) {
        el.classList.remove('fb-gano', 'fb-perdio');
        void el.offsetWidth; // reflow, para poder repetir la animación
        el.classList.add(gano ? 'fb-gano' : 'fb-perdio');
      }
      // Haptic feedback (gratis en código, se siente nativo en PWA instaladas).
      // Patrón doble y corto para victoria (sensación de "celebración"), un
      // solo pulso seco para derrota. navigator.vibrate no existe en iOS
      // Safari/PWA — el try/catch + chequeo de existencia lo vuelve un no-op ahí.
      if (navigator.vibrate) {
        try { navigator.vibrate(gano ? [15, 50, 25] : 30); } catch {}
      }
      if (gano) {
        sonidoVictoria();
        dispararConfeti(el);
      } else {
        sonidoDerrota();
      }
    }

    // ── Sonidos generales de UI (notificación / confirmación) ────────────────
    // Mismo motor de audio que sonidoVictoria/sonidoDerrota, pero pensado para
    // microinteracciones discretas: avisar una notificación nueva o confirmar
    // que una acción (transferencia, compra, registro) se completó bien.
    function sonidoNotificacion() {
      const ctx = _fbGetCtx(); if (!ctx) return;
      // Dos tonos cortos tipo "ping" suave, no intrusivo
      const notas = [880, 1108.73];
      notas.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.value = freq;
        const t = ctx.currentTime + i * 0.1;
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.09, t + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
        osc.start(t); osc.stop(t + 0.24);
      });
    }

    function sonidoConfirmacion() {
      const ctx = _fbGetCtx(); if (!ctx) return;
      // Click breve y limpio, tipo "listo" — para transferencias, compras,
      // registros y otras acciones exitosas que no son apuestas/juegos.
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'sine';
      const t = ctx.currentTime;
      osc.frequency.setValueAtTime(660, t);
      osc.frequency.exponentialRampToValueAtTime(990, t + 0.09);
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.12, t + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
      osc.start(t); osc.stop(t + 0.2);
    }

    // ── Cerrar modales con Escape ────────────────────────────────────────────
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      // Panel de notificaciones
      if (typeof notifCerrar === 'function') notifCerrar();
      // Modales de banco/admin (clase admin-modal-overlay con toggle 'visible')
      ['modal-saldo', 'modal-reset', 'modal-editar-prod', 'modal-recibo-transferencia', 'modal-top-ricos'].forEach(id => {
        const el = document.getElementById(id);
        if (el && el.classList.contains('visible')) el.classList.remove('visible');
      });
      // Modal de apuesta deportiva
      const apModal = document.getElementById('ap-modal-overlay');
      if (apModal && apModal.classList.contains('open')) {
        apModal.classList.remove('open');
        if (typeof apPartidoActivo !== 'undefined') { apPartidoActivo = null; apTipoActivo = null; apEleccion = null; }
      }
      // Modal editar partido (admin casino)
      const admModal = document.getElementById('adm-edit-overlay');
      if (admModal && admModal.classList.contains('open')) admModal.classList.remove('open');
    });

    // ── Service Worker (PWA: cache de estáticos + soporte offline básico) ──
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then((reg) => {
          // Chequea si hay un sw.js nuevo apenas carga la página...
          reg.update().catch(() => {});
          // ...y también cada vez que la pestaña/app vuelve a primer plano
          // (clave en celular: la app queda "abierta" en background días
          // enteras sin recargar, así que sin esto nunca se entera de updates).
          document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') reg.update().catch(() => {});
          });
        }).catch(() => {
          // Si falla el registro (ej. navegador raro), la app sigue funcionando normal sin SW.
        });

        // Cuando el SW nuevo toma el control, recargamos una sola vez para
        // que se vea el CSS/JS actualizado sin que el usuario tenga que
        // cerrar la app o hacer nada manual.
        let ccSwYaRecargo = false;
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          if (ccSwYaRecargo) return;
          ccSwYaRecargo = true;
          window.location.reload();
        });
      });
    }

    // ── Indicador de sin conexión ─────────────────────────────────────────────
    // El sw.js ya sirve estáticos/HTML cacheados cuando no hay red, pero eso es
    // invisible para el usuario: podría estar viendo un saldo o un partido
    // desactualizado sin saberlo, o intentar una apuesta que nunca llega al
    // servidor. Este banner discreto avisa el estado real de la conexión.
    function ccActualizarBannerOffline() {
      let banner = document.getElementById('offline-banner');
      if (!banner) {
        banner = document.createElement('div');
        banner.id = 'offline-banner';
        banner.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="1" y1="1" x2="23" y2="23"/><path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"/><path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"/><path d="M10.71 5.05A16 16 0 0 1 22.58 9"/><path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg><span>Sin conexión — mostrando datos guardados</span>`;
        document.body.appendChild(banner);
      }
      banner.classList.toggle('visible', !navigator.onLine);
    }
    window.addEventListener('online', ccActualizarBannerOffline);
    window.addEventListener('offline', ccActualizarBannerOffline);
    document.addEventListener('DOMContentLoaded', ccActualizarBannerOffline);

    // ── Card de Perfil del dashboard (avatar, badges de RUT/cargo, saldo) ────
    // Se llama al entrar al dashboard. Reutiliza /api/dni, /api/admin y
    // /api/banco (no se crean endpoints nuevos, ya se llegó al límite de 12
    // funciones serverless del plan gratuito de Vercel).
    async function cargarPerfilDashboard() {
      const badgesWrap = document.getElementById('profile-badges');
      if (!badgesWrap || !currentUser?.id) return;

      badgesWrap.innerHTML = `<span class="profile-badge pb-discord">@${escHtml(currentUser.tag || currentUser.name)}</span>`;

      // RUT (badge clickeable si aún no tiene cédula creada)
      try {
        const res = await fetch('/api/dni');
        const data = await res.json();
        if (data.existe && data.dni) {
          currentDNI = data.dni;
          badgesWrap.insertAdjacentHTML('beforeend',
            `<span class="profile-badge pb-rut"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="M8 10h8M8 14h5"/><circle cx="6" cy="12" r="1.3" fill="currentColor"/></svg> ${escHtml(data.dni.rut || '')}</span>`);
        } else {
          badgesWrap.insertAdjacentHTML('beforeend',
            `<span class="profile-badge pb-sin-rut" onclick="abrirSeccion('registro-civil')"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="M8 10h8M8 14h5"/><circle cx="6" cy="12" r="1.3" fill="currentColor"/></svg> Sin cédula — crear</span>`);
        }
      } catch (e) {
        // Sin RUT visible si falla la carga; no bloquea el resto del perfil.
      }

      // Cargo (civil / staff / admin). Se resuelve contra el servidor, igual
      // que en abrirPanelAdmin/abrirPanelStaff — nunca se confía en el cliente.
      try {
        const [rAdmin, rStaff] = await Promise.all([
          fetch('/api/admin?action=verificar'),
          fetch('/api/admin?action=verificarStaff')
        ]);
        const [dAdmin, dStaff] = await Promise.all([rAdmin.json(), rStaff.json()]);

        // Tarjetas de Staff/Admin del dashboard: solo se muestran a quien
        // realmente tiene el rol (misma verificación que abrirPanelAdmin/
        // abrirPanelStaff, nunca se confía en el cliente para ocultarlas
        // como única barrera, solo para no mostrar ruido a usuarios civiles).
        // Existen dos copias en el HTML (versión agrupada mobile y versión
        // plana desktop, ver .nav-mobile-only/.nav-desktop-only en
        // styles.css), por eso se togglean por clase y no por id único.
        document.querySelectorAll('.js-staff-card').forEach(el => {
          el.style.display = dStaff.esStaff ? '' : 'none';
        });
        document.querySelectorAll('.js-admin-card').forEach(el => {
          el.style.display = dAdmin.esAdmin ? '' : 'none';
        });
        const staffSection = document.getElementById('nav-section-staff');
        if (staffSection) staffSection.style.display = (dStaff.esStaff || dAdmin.esAdmin) ? '' : 'none';

        let cargoHtml;
        if (dAdmin.esAdmin) {
          cargoHtml = `<span class="profile-badge pb-admin"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9.5 12l1.8 1.8L15 10"/></svg> Admin</span>`;
        } else if (dStaff.esStaff) {
          cargoHtml = `<span class="profile-badge pb-staff"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg> Staff</span>`;
        } else {
          cargoHtml = `<span class="profile-badge pb-civil"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg> Civil</span>`;
        }
        badgesWrap.insertAdjacentHTML('beforeend', cargoHtml);
      } catch (e) {
        badgesWrap.insertAdjacentHTML('beforeend', `<span class="profile-badge pb-civil"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg> Civil</span>`);
      }

      // Saldo bancario
      const balEl    = document.getElementById('profile-balance');
      const balSubEl = document.getElementById('profile-balance-sub');
      try {
        const res = await fetch('/api/banco?action=cuenta');
        if (res.status === 404) {
          balEl.textContent = '—';
          balSubEl.textContent = 'Aún no tienes cuenta bancaria';
        } else {
          const data = await res.json();
          if (res.ok && data.cuenta) {
            currentCuenta = data.cuenta;
            ccAnimateNumber(balEl, data.cuenta.saldo, formatCLP);
            balSubEl.textContent = `Cuenta N° ${data.cuenta.numero_cuenta}`;
          } else {
            balEl.textContent = '—';
            balSubEl.textContent = 'No se pudo cargar el saldo';
          }
        }
      } catch (e) {
        balEl.textContent = '—';
        balSubEl.textContent = 'Sin conexión';
      }

      cargarTopRicosHero();
    }

    // ── Mini-ranking Top Ricos en la card de primera plana ────────────────────
    // Muestra solo el top 3 (vista rápida); el detalle completo (top 10 +
    // "tu posición") vive en el modal que abre abrirModalTopRicos() (banco.js).
    async function cargarTopRicosHero() {
      const lista = document.getElementById('top-hero-lista');
      if (!lista || !currentUser?.id) return;
      try {
        const res = await fetch(`/api/banco?action=top10&discord_id=${currentUser.id}`);
        const data = await res.json();
        const top3 = (data.ranking || []).slice(0, 3);

        if (top3.length === 0) {
          lista.innerHTML = '<div class="top-hero-empty">Aún no hay cuentas bancarias</div>';
          return;
        }

        const claseRango = (pos) => pos === 1 ? 'gold' : pos === 2 ? 'silver' : 'bronze';
        lista.innerHTML = top3.map(r => {
          const nombre = r.discord_username ? `@${escHtml(r.discord_username)}` : `Ciudadano ${r.discord_id.slice(-4)}`;
          return `
            <div class="top-hero-row">
              <div class="top-hero-pos ${claseRango(r.posicion)}">${r.posicion}</div>
              <div class="top-hero-nombre">${nombre}</div>
              <div class="top-hero-monto">${formatCLP(r.saldo)}</div>
            </div>`;
        }).join('');
      } catch (e) {
        lista.innerHTML = '<div class="top-hero-empty">Error al cargar</div>';
      }
    }

